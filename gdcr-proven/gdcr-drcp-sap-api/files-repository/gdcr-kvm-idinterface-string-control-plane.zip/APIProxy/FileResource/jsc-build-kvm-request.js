// ============================================================================
// GDCR - KVM Toggle Logic for kvm.idinterface
// By Ricardo Luz Holanda Viana
// IA Agent to manage the kvm.idinterface string for onboarding vendors
// HTTP facade and SAP CPI HTTP endpoints
// Format: key:adapter,key:adapter,...
// Example entry: dcrporderscsalesforceid01:http
// ============================================================================

// Current full KVM string for kvm.idinterface (may be null or empty)
var current = context.getVariable('kvm.currentValue');

// Entry to toggle coming from the request body (already "key:adapter")
var incoming = context.getVariable('kvmValue'); // e.g. "dcrpordersusalesforceemeaid02:http"

// Debug (optional)
// context.setVariable('debug.current', current);
// context.setVariable('debug.incoming', incoming);

// Normalize current (handle null and literal "null")
if (!current || current === 'null') {
    current = '';
}

// Normalize incoming
if (!incoming || incoming === 'null') {
    incoming = '';
}

// If there is no incoming value, do NOT change the KVM
if (!incoming) {
    context.setVariable('kvm.mergedValue', current);
} else {
    var merged;

    if (!current) {
        // KVM is empty → insert the new entry
        merged = incoming;
    } else {
        // Split current list into array
        var parts = current.split(',');
        var cleaned = [];
        var found = false;

        for (var i = 0; i < parts.length; i++) {
            var item = parts[i].trim();
            if (item === incoming) {
                // Entry already exists → mark for removal (do not push)
                found = true;
            } else if (item) {
                cleaned.push(item);
            }
        }

        if (found) {
            // Entry existed → we removed it
            merged = cleaned.join(',');
        } else {
            // Entry not found → append it
            cleaned.push(incoming);
            merged = cleaned.join(',');
        }
    }

    // Final guard: never overwrite with empty/undefined value
    if (typeof merged === 'undefined' || merged === null) {
        context.setVariable('kvm.mergedValue', current);
    } else {
        context.setVariable('kvm.mergedValue', merged);
    }
}
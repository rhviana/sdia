// Execute routing
routingDCRP()
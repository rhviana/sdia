// Execute hacking
hackingProtection()